detectron2.layers 
=========================

.. automodule:: detectron2.layers
    :members:
    :undoc-members:
    :show-inheritance:
